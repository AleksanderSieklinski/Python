'''\nZad1 polega na stworzeniu klasy definiujacej punkt na plaszczyznie.\n'''
#1 Proszę utworzyć klasę definiującą współrzędne punktu na płaszczyźnie. 
# Obie współrzędne proszę zdefiniować jako własności (metoda inicjalizacyjna bezparametrowa) (1p)

class Punkt:
    def __init__(self):
        self.x = 0
        self.y = 0