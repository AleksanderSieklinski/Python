'''\nZad1 polega na dopisania do pliku rozszerzenia funckji sumujacej swoje argumenty.\n'''
#1 Proszę zapisać plik rozszerzenia (mod.c) oraz skrypt instalacyjny (setup.py). Proszę tak zmodyfikować plik rozszerzenia, aby otrzymywany wynik był poprawny.

#import os

#os.system("python3 setup.py build")
#import mod

#mod.met(1,2)                 #3
#mod.met(1,2,5)               #8
#mod.met(1,2,5,[2,3,4])       #17  
